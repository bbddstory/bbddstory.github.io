
0.0.2 / 2013-03-26
==================

 - Cache the return value
 - Don't use `setTimeout()`

0.0.1 / 2013-03-26
==================

 - Initial release
