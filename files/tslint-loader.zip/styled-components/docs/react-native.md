**The documentation has been moved to [styled-components.com](https://www.styled-components.com/docs/basics#react-native), please update your bookmarks!**
