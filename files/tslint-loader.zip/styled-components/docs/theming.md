**The documentation has been moved to [styled-components.com](https://www.styled-components.com/docs/advanced#theming), please update your bookmarks!**
