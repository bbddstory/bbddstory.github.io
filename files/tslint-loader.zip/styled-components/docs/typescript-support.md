**The documentation has been moved to [styled-components.com](https://www.styled-components.com/docs/api#typescript), please update your bookmarks!**
