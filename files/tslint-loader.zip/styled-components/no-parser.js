/* eslint-disable */
module.exports = require('./lib/no-parser')
