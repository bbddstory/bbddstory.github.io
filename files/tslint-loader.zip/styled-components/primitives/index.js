/* eslint-disable flowtype/require-valid-file-annotation */
module.exports = require('../lib/primitives')
