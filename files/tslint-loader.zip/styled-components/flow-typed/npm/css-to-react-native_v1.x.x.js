declare module 'css-to-react-native' {
  declare module.exports: ([string, string])[] => { [key:string]: any }
}
