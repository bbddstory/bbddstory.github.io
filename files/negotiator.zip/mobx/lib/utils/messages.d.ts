export declare function getMessage(id: string): string;
