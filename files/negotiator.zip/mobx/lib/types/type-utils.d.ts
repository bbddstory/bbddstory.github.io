import { IDepTreeNode } from "../core/observable";
export declare function getAtom(thing: any, property?: string): IDepTreeNode;
export declare function getAdministration(thing: any, property?: string): any;
export declare function getDebugName(thing: any, property?: string): string;
