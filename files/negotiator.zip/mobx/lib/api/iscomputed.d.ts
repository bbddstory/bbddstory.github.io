export declare function isComputed(value: any, property?: string): boolean;
