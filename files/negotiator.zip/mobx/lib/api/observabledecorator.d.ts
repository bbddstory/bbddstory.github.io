import { IEnhancer } from "../types/modifiers";
export declare function createDecoratorForEnhancer(enhancer: IEnhancer<any>): any;
