export declare function whyRun(thing?: any, prop?: string): string;
