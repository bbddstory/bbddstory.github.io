# 0.3.0

- Enable file mode preservation

# 0.2.1

- Update graceful-fs to 4.x
