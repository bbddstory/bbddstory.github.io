import ace from './ace.js'
import split from './split.js';
export {
  split
}
export default ace