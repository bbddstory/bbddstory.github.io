# Installation
> `npm install --save @types/mime`

# Summary
This package contains type definitions for mime (https://github.com/broofa/node-mime).

# Details
Files were exported from https://www.github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/mime

Additional Details
 * Last updated: Tue, 20 Jun 2017 20:20:01 GMT
 * Dependencies: none
 * Global values: mime

# Credits
These definitions were written by Jeff Goddard <https://github.com/jedigo>.
