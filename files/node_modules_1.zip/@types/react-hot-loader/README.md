# Installation
> `npm install --save @types/react-hot-loader`

# Summary
This package contains type definitions for react-hot-loader (https://github.com/gaearon/react-hot-loader).

# Details
Files were exported from https://www.github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/react-hot-loader

Additional Details
 * Last updated: Fri, 30 Jun 2017 21:28:46 GMT
 * Dependencies: react
 * Global values: none

# Credits
These definitions were written by Jacek Jagiello <https://github.com/jacekjagiello/>.
