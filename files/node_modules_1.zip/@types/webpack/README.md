# Installation
> `npm install --save @types/webpack`

# Summary
This package contains type definitions for webpack (https://github.com/webpack/webpack).

# Details
Files were exported from https://www.github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/webpack

Additional Details
 * Last updated: Fri, 16 Jun 2017 16:37:51 GMT
 * Dependencies: tapable, uglify-js, node
 * Global values: none

# Credits
These definitions were written by Qubo <https://github.com/tkqubo>, Matt Lewis <https://github.com/mattlewis92>, Benjamin Lim <https://github.com/bumbleblym>, Boris Cherny <https://github.com/bcherny>, Tommy Troy Lin <https://github.com/tommytroylin>.
