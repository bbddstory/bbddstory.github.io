# Installation
> `npm install --save @types/source-map`

# Summary
This package contains type definitions for source-map v0.5.6 (https://github.com/mozilla/source-map).

# Details
Files were exported from https://www.github.com/DefinitelyTyped/DefinitelyTyped/tree/types-2.0/source-map

Additional Details
 * Last updated: Mon, 14 Nov 2016 19:35:02 GMT
 * File structure: UMD
 * Library Dependencies: none
 * Module Dependencies: none
 * Global values: SourceMap, sourceMap

# Credits
These definitions were written by Morten Houston Ludvigsen <https://github.com/MortenHoustonLudvigsen>.
