# Installation
> `npm install --save @types/webpack-env`

# Summary
This package contains type definitions for webpack (module API) (https://github.com/webpack/webpack).

# Details
Files were exported from https://www.github.com/DefinitelyTyped/DefinitelyTyped/tree/master/webpack-env

Additional Details
 * Last updated: Thu, 05 Jan 2017 06:25:10 GMT
 * Library Dependencies: none
 * Module Dependencies: none
 * Global values: DEBUG, __non_webpack_require__, __resourceQuery, __webpack_chunk_load__, __webpack_hash__, __webpack_modules__, __webpack_public_path__, __webpack_require__, module, require

# Credits
These definitions were written by use-strict <https://github.com/use-strict>.
