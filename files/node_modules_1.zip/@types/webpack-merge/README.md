# Installation
> `npm install --save @types/webpack-merge`

# Summary
This package contains type definitions for webpack-merge (https://github.com/survivejs/webpack-merge).

# Details
Files were exported from https://www.github.com/DefinitelyTyped/DefinitelyTyped/tree/types-2.0/webpack-merge

Additional Details
 * Last updated: Mon, 21 Nov 2016 21:03:00 GMT
 * File structure: ModuleAugmentation
 * Library Dependencies: webpack
 * Module Dependencies: webpack
 * Global values: none

# Credits
These definitions were written by Simon Hartcher <https://github.com/deevus>.
