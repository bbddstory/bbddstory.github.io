# Installation
> `npm install --save @types/express`

# Summary
This package contains type definitions for Express (http://expressjs.com).

# Details
Files were exported from https://www.github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/express

Additional Details
 * Last updated: Thu, 15 Jun 2017 20:13:09 GMT
 * Dependencies: serve-static, express-serve-static-core
 * Global values: none

# Credits
These definitions were written by Boris Yankov <https://github.com/borisyankov/>.
