import opn from 'opn';

const url = 'https://twitter.com/opencollect';
console.log("Opening", url);
opn(url);

process.exit(0);