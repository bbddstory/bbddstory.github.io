require('../../modules/es7.object.entries');
module.exports = require('../../modules/$.core').Object.entries;