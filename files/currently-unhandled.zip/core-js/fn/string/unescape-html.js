require('../../modules/core.string.unescape-html');
module.exports = require('../../modules/$.core').String.unescapeHTML;