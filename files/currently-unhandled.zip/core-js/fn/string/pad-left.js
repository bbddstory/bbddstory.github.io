require('../../modules/es7.string.pad-left');
module.exports = require('../../modules/$.core').String.padLeft;