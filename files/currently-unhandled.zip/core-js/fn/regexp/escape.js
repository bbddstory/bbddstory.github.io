require('../../modules/es7.regexp.escape');
module.exports = require('../../modules/$.core').RegExp.escape;