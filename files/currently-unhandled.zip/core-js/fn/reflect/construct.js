require('../../modules/es6.reflect.construct');
module.exports = require('../../modules/$.core').Reflect.construct;