require('../../modules/es7.array.includes');
module.exports = require('../../modules/$.core').Array.includes;