require('../../modules/es6.array.iterator');
module.exports = require('../../modules/$.core').Array.entries;