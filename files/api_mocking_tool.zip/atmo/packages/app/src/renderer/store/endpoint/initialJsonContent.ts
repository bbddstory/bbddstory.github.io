const initialJson = `{
  greeting: "Hello from atmo!"
}
`;

export default initialJson;
