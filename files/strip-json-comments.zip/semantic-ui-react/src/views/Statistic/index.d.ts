export { default, StatisticProps } from './Statistic';
