export { default, CommentProps } from './Comment';
