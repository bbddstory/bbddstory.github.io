export { default, TextAreaProps, TextAreaOnChangeData } from './TextArea';
