export { default, ConfirmProps } from './Confirm';
