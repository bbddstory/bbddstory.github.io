export { default, InputProps, InputOnChangeData } from './Input';
