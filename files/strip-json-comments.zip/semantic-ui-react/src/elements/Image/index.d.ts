export { default, ImageProps } from './Image';
