export { default, IconProps } from './Icon';
