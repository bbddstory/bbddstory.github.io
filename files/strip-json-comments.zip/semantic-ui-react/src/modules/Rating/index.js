export default from './Rating'
