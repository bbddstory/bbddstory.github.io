export { default, TabProps } from './Tab';
