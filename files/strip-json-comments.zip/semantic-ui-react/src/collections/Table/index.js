export default from './Table'
