export { default, TableProps } from './Table';
