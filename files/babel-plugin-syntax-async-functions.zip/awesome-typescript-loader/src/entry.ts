require('source-map-support').install();
module.exports = require('./index');
