# Installation
> `npm install --save @types/serve-static`

# Summary
This package contains type definitions for serve-static 1.7.1 (https://github.com/expressjs/serve-static).

# Details
Files were exported from https://www.github.com/DefinitelyTyped/DefinitelyTyped/tree/types-2.0/serve-static

Additional Details
 * Last updated: Mon, 19 Sep 2016 17:28:59 GMT
 * File structure: ProperModule
 * Library Dependencies: express-serve-static-core
 * Module Dependencies: express-serve-static-core, mime
 * Global values: serveStatic

# Credits
These definitions were written by Uros Smolnik <https://github.com/urossmolnik/>.
