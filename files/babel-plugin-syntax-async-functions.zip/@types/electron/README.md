This is a stub types definition for electron (https://github.com/electron/electron).
electron provides its own type definitions, so you don't need @types/electron installed!