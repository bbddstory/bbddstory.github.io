# Installation
> `npm install --save @types/uglify-js`

# Summary
This package contains type definitions for UglifyJS 2 (https://github.com/mishoo/UglifyJS2).

# Details
Files were exported from https://www.github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/uglify-js

Additional Details
 * Last updated: Mon, 05 Jun 2017 19:59:14 GMT
 * Dependencies: source-map
 * Global values: none

# Credits
These definitions were written by Tanguy Krotoff <https://github.com/tkrotoff>.
