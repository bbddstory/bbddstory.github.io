# Installation
> `npm install --save @types/es6-promise`

# Summary
This package contains type definitions for es6-promise (https://github.com/jakearchibald/ES6-Promise).

# Details
Files were exported from https://www.github.com/DefinitelyTyped/DefinitelyTyped/tree/types-2.0/es6-promise

Additional Details
 * Last updated: Mon, 19 Sep 2016 17:28:58 GMT
 * File structure: Mixed
 * Library Dependencies: none
 * Module Dependencies: none
 * Global values: Promise

# Credits
These definitions were written by François de Campredon <https://github.com/fdecampredon/>, vvakame <https://github.com/vvakame>.
