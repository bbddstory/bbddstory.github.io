var less = {
    logLevel: 4,
    errorReporting: "console",
    strictMath: false,
    strictUnits: false };
