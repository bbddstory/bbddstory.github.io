## 0.9.9 / 2013-01-28 01:20 AM

  - Re-write tests to Mocha
  - Remove 'null' and 'undefined' filter
  - Fix Cakefile 

## 0.9.7 / 2012-06-21 02:54 PM

  - Rename extend.{ext} -> whet.extend.{ext}

## 0.9.5 / 2012-05-24 07:56 PM

  - Add travis-ci tests
  - fix index.js


## 0.9.4 / 2012-05-24 03:08 PM

  - Move .coffee to ./scr, add compiled .js version to ./lib
  - Move CoffeeScript to develop dependencies
  - Add Cakefile
  - Doc improved
  - Small fix


## 0.9.1 / 2012-05-17 11:05 AM

  - Initial release