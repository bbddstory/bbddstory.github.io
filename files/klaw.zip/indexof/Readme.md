
# indexOf

  Lame indexOf thing, thanks microsoft

## Example

```js
var index = require('indexof');
index(arr, obj);
```

## License

  MIT