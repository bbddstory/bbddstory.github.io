  // All code before this point will be filtered from stack traces.
  var rEndingLine = captureLine();
